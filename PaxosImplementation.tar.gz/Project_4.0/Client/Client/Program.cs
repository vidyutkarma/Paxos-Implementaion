﻿using System;
using System.Net;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Configuration;

namespace Clients
{
    class Client
    {
        static void Main(string[] args)
        {
            int intKey;
            string clientInfo = Guid.NewGuid().ToString();
            string consoleInput = "";
            string serverResult = "";
            IPAddress serverIP;
            int serverPort;
            char[] delimiter = { ':' };
            bool leadServer = false;
            TwoPhaseServer.TwoPhaseServerMethods workObject = null;
            String[] mylist;
            HttpChannel channel = new HttpChannel();
            ChannelServices.RegisterChannel(channel);
            foreach (string strserverPort in ConfigurationManager.AppSettings)
            {
                leadServer = false;
                mylist = ConfigurationManager.AppSettings[strserverPort].ToString().Split(delimiter);
                serverIP = IPAddress.Parse(mylist[0]);
                serverPort = Convert.ToInt16(mylist[1]);
	            Console.WriteLine("Trying to connect" + serverIP + serverPort);
                try
                {
                    
                    workObject = (TwoPhaseServer.TwoPhaseServerMethods)Activator.GetObject(typeof(TwoPhaseServer.TwoPhaseServerMethods), "http://" + serverIP + ":" + serverPort.ToString() + "/MyTwoPhaseServerMethods");
                    //workObject = new TwoPhaseServer.TwoPhaseServerMethods();
                    leadServer = workObject.IsLeader();
                    Console.WriteLine("Connection established successfully to the Lead Server");
                    break;
                    //if (leadServer)
                    //{
                    //    Log(serverIP + ":" + serverPort, " : " + "Successful" + "  logtime: ");
                    //    Console.WriteLine("Connection established successfully to the Lead Server");
                    //    break;
                    //}
                    
                }
                catch (Exception ex)
                {
                    Log("Connection to Server: " + serverIP + ":" + serverPort, " : " + "Failed" + "\n Error Message : " + ex.Message + "\n logtime:");
                    
                }
            }
            if (true)
            {
                do
                {
                    try
                    {
                        string sendToServer;

                        do
                        {
                            Console.WriteLine("Please enter the action or 'end' to exit");
                            consoleInput = Console.ReadLine();
                            switch (consoleInput.ToUpper())
                            {
                                case "GET":
                                    {
                                        Console.WriteLine("Please enter the key or 'end' to exit");
                                        do
                                        {
                                            sendToServer = Console.ReadLine();
                                            if (int.TryParse(sendToServer, out intKey))
                                            {
                                                serverResult = workObject.Get(clientInfo, intKey);
                                                if (serverResult != "Not Found")
                                                {
                                                    serverResult = serverResult.Substring(5);
                                                }
                                                else
                                                {
                                                    serverResult = "Key Not Found";
                                                }
                                                Console.WriteLine(serverResult);
                                                Log("Client Instance ID: " + clientInfo, "Action = GET; Result = Success; ");
                                                break;
                                            }
                                            else if (sendToServer.ToUpper() != "END")
                                                Console.WriteLine("Invalid Key. Enter valid key or 'end' to exit this action");

                                        } while (sendToServer.ToUpper() != "END");
                                    }
                                    break;
                                case "PUT":
                                    {
                                        Console.WriteLine("Please enter the key or 'end' to exit");
                                        do
                                        {
                                            sendToServer = Console.ReadLine();
                                            if (int.TryParse(sendToServer, out intKey))
                                            {

                                                Console.WriteLine("Please enter the value");
                                                string value = Console.ReadLine();
                                                serverResult = workObject.Put(clientInfo, intKey, value);
                                                Console.WriteLine(serverResult);
                                                break;
                                            }
                                            else if (sendToServer.ToUpper() != "END")
                                                Console.WriteLine("Invalid Key. Enter valid key or 'end' to exit this action");

                                        } while (sendToServer.ToUpper() != "END");
                                    }
                                    break;
                                case "DELETE":
                                    {
                                        Console.WriteLine("Please enter the key or 'end' to exit");
                                        do
                                        {
                                            sendToServer = Console.ReadLine();
                                            if (int.TryParse(sendToServer, out intKey))
                                            {
                                                serverResult = workObject.Delete(clientInfo, intKey);
                                                Console.WriteLine(serverResult);
                                                break;
                                            }
                                            else if (sendToServer.ToUpper() != "END")
                                                Console.WriteLine("Invalid Key. Enter valid key or 'end' to exit this action");

                                        } while (sendToServer.ToUpper() != "END");
                                    }
                                    break;
				 case "END":
				    {
					Console.WriteLine("Bye");
				    }
				    break;
                                default:
                                    {
                                        Console.WriteLine("Invalid Action");
                                    }
                                    break;
                            }
                            
                        } while (consoleInput.ToUpper() != "END");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.ToString());
                    }

                } while (consoleInput.ToUpper() != "END");
            }
            else
            {
                Console.WriteLine("Could not establish connection. Please contact system admin.\nCheck client log for more information");
            }
        }
        public static void Log(string clientInfo, string logString)
        {
            using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(@"Log.txt", true))
            {
                logFile.WriteLine(clientInfo + ": " + logString + " " + DateTime.Now.ToString("MM/dd/yyyy hh.mm.ss.ffffff tt"));
            }

        }
    }
}
