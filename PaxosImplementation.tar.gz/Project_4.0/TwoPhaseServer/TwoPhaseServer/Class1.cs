﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace TwoPhaseServer
{
    public class RemoteServerObjects
    {
        public TwoPhaseServer.TwoPhaseServerMethods workobject { get; set; }
        public string response {get; set;}
        public string voteResponse { get; set; }
    }
    public class TwoPhaseServerMethods : MarshalByRefObject
    {
        IPAddress serverIP;
        int serverPort;
        static char[] delimiter = { ':' };
        bool isConnSuccess;
        static IPAddress localServerIP = LocalIP();
        static int currentProposal;
        string valueReturnedAfterProposal = String.Empty;
        int ballotParticipationCount;
        //int maxBallot;
        RemoteServerObjects[] serverObjectsList = new RemoteServerObjects[10];
        string prevVote;
        string prevBallot;
        TwoPhaseServer.TwoPhaseServerMethods workObject;
        String[] mylist;

        //Phase 1: Loop through all servers and check whether they are active.
        public bool ProposalProcess(ref string valueReturnedAfterProposal)
        {
            //defining variables that will be needed during this process
            int positiveResponseCount = 0;
            string selectedVote = String.Empty;
            int responseMaxBallot = 0;
            bool proposalSuccess = false;
            Stopwatch responseMonitor = new Stopwatch();
            responseMonitor.Start();
            //initializing the serverObjectsList. We will be using the response to check if we need to propose a value to it
            for ( int i = 0; i < 10; i++ )
            {
                serverObjectsList[i] = new RemoteServerObjects { workobject = null, response = "NotConnected" };
            }
            do
            {
                
                int totalServerCount = 0;
                currentProposal = ProposalNumber();
                foreach (string strserverPort in ConfigurationManager.AppSettings)
                {
                    mylist = ConfigurationManager.AppSettings[strserverPort].ToString().Split(delimiter);
                    serverIP = IPAddress.Parse(mylist[0]);
                    serverPort = Convert.ToInt16(mylist[1]);
                    totalServerCount +=1;
                    if (serverObjectsList[totalServerCount].response == "NotConnected")
                    {
                    try
                        {
                            string[] splitResponse;
                            serverObjectsList[totalServerCount].workobject = (TwoPhaseServer.TwoPhaseServerMethods)Activator.GetObject(typeof(TwoPhaseServer.TwoPhaseServerMethods), "http://" + serverIP + ":" + serverPort.ToString() + "/MyTwoPhaseServerMethods");
                            serverObjectsList[totalServerCount].response = serverObjectsList[totalServerCount].workobject.Propose(currentProposal);
                            splitResponse = serverObjectsList[totalServerCount].response.Split(';');
                            Console.WriteLine("split Response is {0}, {1}, {2}", splitResponse[0], splitResponse[1], splitResponse[1]);
                            if (Convert.ToInt32(splitResponse[0]) == currentProposal)
                            {
                                positiveResponseCount +=1;
                                if (Convert.ToInt32(splitResponse[2]) > responseMaxBallot)
                                {
                                    responseMaxBallot = Convert.ToInt32(splitResponse[2]);
                                    selectedVote = splitResponse[1];
                                }
                            }
                       // Console.WriteLine("")
                            Log(serverIP + ":" + serverPort, " : " + "Successful" + "  logtime: ");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            Log("Connection to Server: " + serverIP + ":" + serverPort, " : " + "Failed" + "\n Error Message : " + ex.Message + "\n logtime:");

                        }
                    }
                }
                
                if (positiveResponseCount > totalServerCount / 2)
                    proposalSuccess = true;
                Console.WriteLine("proposal success is {0}, {1}, {2}", proposalSuccess.ToString(), positiveResponseCount, totalServerCount);
            } while (!proposalSuccess || responseMonitor.Elapsed.TotalSeconds < 5 );
            responseMonitor.Stop();
            ballotParticipationCount = positiveResponseCount;
            if (selectedVote != String.Empty)
            {
                valueReturnedAfterProposal = selectedVote;
            }
            return proposalSuccess;
            Console.WriteLine("Leaving proposalProcess {0}, {1}", valueReturnedAfterProposal, proposalSuccess);
        }
        public string Put(string clientInfo, int key, string value)
        {

            string proposalValue = "Put:" + key + ":" + value + ":" + clientInfo;
            string valueReturnedAfterProposal = String.Empty;
            int positiveResponseCount = 0;
            Methods.Methods myMethods = new Methods.Methods();
            if (myMethods.Get(clientInfo, key) != "Not Found")
            {
                return "Key already present";
            }

            do
            {
            if (ProposalProcess(ref valueReturnedAfterProposal))
            {
                string[] splitResponse;
                if (valueReturnedAfterProposal == String.Empty)
                {
                    valueReturnedAfterProposal = proposalValue;
                }
                Console.WriteLine("bEFORE entering begin ballot");
                foreach (RemoteServerObjects serverObject in serverObjectsList)
                {
                    if (serverObject.response != "NotConnected")
                    {
                        serverObject.voteResponse = serverObject.workobject.BeginBallot(currentProposal, valueReturnedAfterProposal);
                        splitResponse = serverObject.voteResponse.Split(':');
                        if ((splitResponse[0] == "Voted") && (Convert.ToInt32(splitResponse[1]) == currentProposal))
                        {
                            positiveResponseCount += 1;
                        }
                    }
                }
                if (positiveResponseCount == ballotParticipationCount)
                {
                    Thread successThread = new Thread(
                       o =>
                       {
                           Success((string)o);
                       });
                    successThread.Start(valueReturnedAfterProposal);
                }
                return "Message Posted";
            }

            else
            {
                return "Cannot perform PUT as Connection to one or more servers has failed. Please try again after sometime or contact the System Admin.";

            }
            }while(proposalValue != valueReturnedAfterProposal);
        }

        public string Delete(string clientInfo, int key)
        {
            string proposalValue = "Delete:" + key + ":" + clientInfo;
            string valueReturnedAfterProposal = String.Empty;
            int positiveResponseCount = 0;
            Methods.Methods myMethods = new Methods.Methods();
            if (myMethods.Get(clientInfo, key) == "Not Found")
            {
                return "Key Not Found";
            }

            do
            {
                if (ProposalProcess(ref valueReturnedAfterProposal))
                {
                    string[] splitResponse;
                    if (valueReturnedAfterProposal == String.Empty)
                    {
                        valueReturnedAfterProposal = proposalValue;
                    }
                    foreach (RemoteServerObjects serverObject in serverObjectsList)
                    {
                        if (serverObject.response != "NotConnected")
                        {
                            serverObject.voteResponse = serverObject.workobject.BeginBallot(currentProposal, valueReturnedAfterProposal);
                            splitResponse = serverObject.voteResponse.Split(':');
                            if ((splitResponse[0] == "Voted") && (Convert.ToInt32(splitResponse[1]) == currentProposal))
                            {
                                positiveResponseCount += 1;
                            }
                        }
                    }
                    if (positiveResponseCount == ballotParticipationCount)
                    {
                        Thread successThread = new Thread(
                           o =>
                           {
                               Success((string)o);
                           });
                        successThread.Start(valueReturnedAfterProposal);
                    }
                    return "Message Posted";
                }

                else
                {
                    return "Cannot perform DELETE as Connection to one or more servers has failed. Please try again after sometime or contact the System Admin.";

                }
            } while (proposalValue != valueReturnedAfterProposal);
        }


        public string Get(string clientInfo, int key)
        {
            Methods.Methods m = new Methods.Methods();
            string Returnvalue = m.Get(clientInfo, key);
            return Returnvalue;
        }

        public bool IsLeader()
        {
            bool leadServer = false;
            foreach (string strserverPort in ConfigurationManager.AppSettings)
            {
                mylist = ConfigurationManager.AppSettings[strserverPort].ToString().Split(delimiter);
                serverIP = IPAddress.Parse(mylist[0]);
                serverPort = Convert.ToInt16(mylist[1]);
                if ((localServerIP.ToString() == serverIP.ToString()) && mylist[2] == "L")
                {
                    leadServer = true;
                    break;
                }
            }
            return leadServer;
        }
        public string CheckConnection()
        {
            return "Success";
        }

        public void Log(string Serverinfo, string logString)
        {
            using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(@"Log.txt", true))
            {
                logFile.WriteLine("Connection to " + Serverinfo + ": " + logString + " " + DateTime.Now.ToString("MM/dd/yyyy hh.mm.ss.ffffff tt"));
            }

        }
        public static IPAddress LocalIP()
        {
            IPAddress localServerIP = null;
            try
            {

                string host = Dns.GetHostName();
                IPHostEntry hostEntry = Dns.GetHostEntry(host);
                foreach (IPAddress ip in hostEntry.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        localServerIP = ip;
                        break;
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Server IP not found. Error: {0}", ex.ToString());
                throw ex;
            }
            return localServerIP;
        }
        public int ProposalNumber()
        {
            int proposalValue = 0;
            try
            {
                proposalValue = Convert.ToInt16(File.ReadAllLines(@"LastTried.txt").Last()) + 5;
                using (StreamWriter ballotFile = new StreamWriter(@"LastTried.txt", true))
                {
                    ballotFile.WriteLine(proposalValue);
                }
            }
            catch (Exception ex)
            {
                Log("Failed file action ",ex.Message + ": logtime:");
            }
            return proposalValue;
        }
        public string Propose(int seq)
        {
            Console.WriteLine("Entered Propose");
            string returnValue = ";;";
            int maxBallot = Convert.ToInt16(File.ReadAllLines(@"MaxBallot.txt").Last());
            try
            {
                prevVote = File.ReadAllLines(@"PreVote.txt").Last();
            }
            catch (InvalidOperationException)
            {
                prevVote = String.Empty; 
            }
            
            if (seq > maxBallot)
            {
                 using (StreamWriter ballotFile = new StreamWriter(@"MaxBallot.txt", true))
                {
                    ballotFile.WriteLine(seq);
                }
                returnValue = seq + ";" + prevVote + ";" + maxBallot;
            }
            Console.WriteLine("Leaving Propose {0}", returnValue);
            return returnValue;
        }
        public string BeginBallot(int seq, string value)
        {
            string returnValue = "NotVoted";
            int maxBallot = Convert.ToInt16(File.ReadAllLines(@"MaxBallot.txt").Last());
            if (seq == maxBallot)
            {
                using (StreamWriter previousVoteFile = new StreamWriter(@"PreVote.txt", true))
                {
                    previousVoteFile.WriteLine(value);
                }
                using (StreamWriter previousBallotFile = new StreamWriter(@"PreBallot.txt", true))
                {
                    previousBallotFile.WriteLine(seq);
                }
                returnValue = "Voted:" + seq;
            }
            return returnValue;
        }
        public void Success(string value)
        {
            try
            {
                int positiveResponseCount = 0;
                int totalServerCount = 0;
                RemoteServerObjects[] serverObjectsWriteList = new RemoteServerObjects[10];
                for (int i = 0; i < 10; i++)
                {
                    serverObjectsWriteList[i] = new RemoteServerObjects { workobject = null, response = "NotWritten" };
                }
                do
                {
                    foreach (string strserverPort in ConfigurationManager.AppSettings)
                    {
                        mylist = ConfigurationManager.AppSettings[strserverPort].ToString().Split(delimiter);
                        serverIP = IPAddress.Parse(mylist[0]);
                        serverPort = Convert.ToInt16(mylist[1]);
                        totalServerCount += 1;
                        if (serverObjectsWriteList[totalServerCount].response == "NotWritten")
                        {
                            try
                            {
                                serverObjectsWriteList[totalServerCount].workobject = (TwoPhaseServer.TwoPhaseServerMethods)Activator.GetObject(typeof(TwoPhaseServer.TwoPhaseServerMethods), "http://" + serverIP + ":" + serverPort.ToString() + "/MyTwoPhaseServerMethods");
                                serverObjectsWriteList[totalServerCount].response = serverObjectsWriteList[totalServerCount].workobject.WriteToServer(value);
                                if (serverObjectsWriteList[totalServerCount].response == "Written")
                                {
                                    positiveResponseCount += 1;
                                }
                                Log(serverIP + ":" + serverPort, " : " + "Successful" + "  logtime: ");
                            }
                            catch (Exception ex)
                            {
                                Log("Connection to Server: " + serverIP + ":" + serverPort, " : " + "Failed" + "\n Error Message : " + ex.Message + "\n logtime:");

                            }
                        }
                    }

                } while (positiveResponseCount < totalServerCount);
            }
            catch (Exception ex)
            {
                Log("Success Method Failure " + serverIP + ":" + serverPort, " : " + "Failed" + "\n Error Message : " + ex.Message + "\n logtime:");
            }
        }
        public string WriteToServer(string value)
        {
            string returnValue = "NotWritten";
            try
            {
                using (StreamWriter actionFile = new StreamWriter(@"tmpActionFile.txt", true))
                {
                    actionFile.WriteLine(value);
                    returnValue = "Written";
                }
                File.Move(@"tmpActionFile.txt", @"ActionFile" + DateTime.Now.ToString("ddMMyyyyhhmmssffff") + ".txt");
                File.Delete(@"PreVote.txt");
                File.Copy(@"PreVoteTmp.txt", @"PreVote.txt");
            }
            catch (Exception ex)
            {
                Log("Connection to Server: " + serverIP + ":" + serverPort, " : " + "Failed" + "\n Error Message : " + ex.Message + "\n logtime:");
            }
            return returnValue;
        }
    }
}
