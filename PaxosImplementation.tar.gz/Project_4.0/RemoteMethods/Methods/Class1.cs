﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Methods
{
    public class Methods: MarshalByRefObject
    {
        string logLine;
        public string Get(string clientInfo, int key)
        {
            string value = "Not Found";
            string line = null;
            try
            {
                using (StreamReader reader = new StreamReader(@"KeyValue.txt"))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Substring(0, 5) == key.ToString("D5"))
                        {
                            value = line;
                            break;
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                logLine = "File not present";
                Log(clientInfo, logLine);
            }
            catch (Exception e)
            {
                logLine = e.ToString();
                Log(clientInfo, logLine);
            }
            return value;
        }
        public string Put(string clientInfo, int key, string value)
        {
            string line = key.ToString("D5") + value;
            string proceed = Get(clientInfo, key);
            if (proceed == "Not Found")
            {
                try
                {
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"KeyValue.txt", true))
                    {
                        file.WriteLine(line);
                    }
                    logLine = line + " written successfully";
                    Log(clientInfo, logLine);
                    return "Success";
                }
                catch (Exception e)
                {
                    logLine = line + "failed to be added with error " + e.ToString();
                    Log(clientInfo, logLine);
                    return "Failure";
                }
            }
            else
            {
                logLine = key.ToString("D5") + " Key already present in file";
                Log(clientInfo, logLine);
                return "Key already present";
            }

        }
        public string Delete(string clientInfo, int key)
        {
            string line = null;
            string proceed = Get(clientInfo, key);
            if (proceed != "Key Not Found")
            {
                try
                {
                    using (StreamReader reader = new StreamReader(@"KeyValue.txt"))
                    {
                        using (StreamWriter writer = new StreamWriter(@"KeyValueTemp.txt"))
                        {
                            while ((line = reader.ReadLine()) != null)
                            {
                                if (line.Substring(0, 5) != key.ToString("D5"))
                                {
                                    writer.WriteLine(line);
                                }
                            }
                        }
                    }
                    File.Delete(@"KeyValue.txt");
                    File.Move(@"KeyValueTemp.txt", @"KeyValue.txt");
                    logLine = key.ToString("D5") + " successfully deleted";
                    return "Successfully deleted";
                }
                catch (Exception e)
                {
                    logLine = "Could not delete key " + key.ToString("D5") + " " + e.ToString();
                    Log(clientInfo, logLine);
                    File.Delete(@"KeyValueTemp.txt");
                    return "Failure while deleting";
                }
            }
            else
            {
                logLine = key.ToString("D5") + " key not found - DELETE";
                Log(clientInfo, logLine);
                return "Key not found";
            }
        }
        public static void Log(string clientInfo, string logString)
        {
            using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(@"Log.txt", true))
            {
                logFile.WriteLine(clientInfo + ": " + logString + " " + DateTime.Now.ToString("MM/dd/yyyy hh.mm.ss.ffffff tt"));
            }

        }
    }

}
