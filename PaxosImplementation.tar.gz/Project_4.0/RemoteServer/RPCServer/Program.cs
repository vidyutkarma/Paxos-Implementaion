﻿using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using System.Net;
using TwoPhaseServer;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Net.Sockets;

namespace RPCServer
{
    class Program
    {


        static void Main(string[] args)
        {
            int intPort;

            if(int.TryParse(args[0],out intPort))
            {
                try
                {
                    HttpChannel channel = new HttpChannel(intPort);
                    ChannelServices.RegisterChannel(channel);
                    RemotingConfiguration.RegisterWellKnownServiceType(typeof(TwoPhaseServer.TwoPhaseServerMethods), "MyTwoPhaseServerMethods", WellKnownObjectMode.SingleCall);
                    Console.WriteLine("Server is listening on port {0}, Press ENTER to exit", intPort);
                    Thread backgroundThread = new Thread(new ThreadStart(BackgroundJob));
                    //thread.Start
                    //Thread backgroundThread = new Thread(
                    //   o =>
                    //   {
                    //       BackgroundJob();
                    //   });
                    backgroundThread.Start();
                    Console.ReadLine();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                
            }
        }
        public static IPAddress LocalIP()
        {
            IPAddress localServerIP = null;
            try
            {

                string host = Dns.GetHostName();
                IPHostEntry hostEntry = Dns.GetHostEntry(host);
                foreach (IPAddress ip in hostEntry.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        localServerIP = ip;
                        break;
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Server IP not found. Error: {0}", ex.ToString());
                throw ex;
            }
            return localServerIP;
        }
        public static void BackgroundJob()
        {
            //function to determine leader and write from Activity file
            bool noLeader = true;
            string[] serverStatus = new string[5];
            int serverIndex = 0;
            try
            {
                do
                {
                    Thread.Sleep(300);
                    string line = String.Empty;
                    string[] activityFiles = Directory.GetFiles(@".\", "ActionFile*");
                    foreach (string fileName in activityFiles)
                    {
                        Console.WriteLine("1");
                        string[] splitLine;
                        Methods.Methods actionMethod = new Methods.Methods();
                        try
                        {
                           using (StreamReader reader = new StreamReader(fileName))
                            {
                                while ((line = reader.ReadLine()) != null)
                                {
                                    splitLine = line.Split(':');
                                    if (splitLine[0] == "Put")
                                    {
                                        actionMethod.Put(splitLine[3], Convert.ToInt32(splitLine[1]), splitLine[2]);
                                    }
                                    else if (splitLine[0] == "Delete")
                                    {
                                        actionMethod.Delete(splitLine[2], Convert.ToInt32(splitLine[1]));
                                    }
                                }
                            }
                            File.Delete(fileName);
                        }
                        catch (FileNotFoundException)
                        {
                            Thread.Sleep(300);
                        }
                        catch (Exception e)
                        {
                            throw e;
                        }
                    }
                    string[] mylist;
                    IPAddress serverIP;
                    int serverPort;
                    IPAddress localServerIP = LocalIP();
                    TwoPhaseServerMethods workObject;
                    string isLeader = String.Empty;
                    serverIndex = 0;
                    Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                    foreach (string strServer in ConfigurationManager.AppSettings)
                    {
                        mylist = ConfigurationManager.AppSettings[strServer].ToString().Split(':');
                        serverIP = IPAddress.Parse(mylist[0]);
                        serverPort = Convert.ToInt16(mylist[1]);
                        isLeader = mylist[2];
                        serverIndex += 1;
                        if (localServerIP.ToString() != serverIP.ToString())
                        {
                            try
                            {
                                string connectionResult = "Failed";
                                workObject = (TwoPhaseServer.TwoPhaseServerMethods)Activator.GetObject(typeof(TwoPhaseServer.TwoPhaseServerMethods), "http://" + serverIP + ":" + serverPort.ToString() + "/MyTwoPhaseServerMethods");
                                connectionResult = workObject.CheckConnection();
                                if (serverStatus[serverIndex - 1] == "NotConnected")
                                {
                                    Console.WriteLine("Server {0} up again", serverIP.ToString());
                                    serverStatus[serverIndex - 1] = "Connected";
                                }
                                
                                if (noLeader)
                                {
                                    
                                    config.AppSettings.Settings[strServer].Value = mylist[0] + ":" + mylist[1] + ":L";
                                    config.Save(ConfigurationSaveMode.Modified);
                                    ConfigurationManager.RefreshSection("appSettings");
                                    noLeader = false;
                                }

                            }
                            catch (Exception ex)
                            {
                                if (serverStatus[serverIndex - 1] != "NotConnected")
                                {
                                    Console.WriteLine("Server {0} down", serverIP.ToString());
                                    serverStatus[serverIndex - 1] = "NotConnected";
                                }
                                
                                if (isLeader == "L")
                                {
                                    
                                    config.AppSettings.Settings[strServer].Value = mylist[0] + ":" + mylist[1];
                                    config.Save(ConfigurationSaveMode.Modified);
                                    ConfigurationManager.RefreshSection("appSettings");

                                    //ConfigurationManager.AppSettings.Remove(strServer);
                                    //ConfigurationManager.AppSettings.Add(strServer, mylist[0] + ":" + mylist[1]);
                                    noLeader = true;
                                }
                                
                            }
                        }
                    }
                } while (true);
            }
            catch (Exception ex)
            {
                Log("Issue with thread " + ex.Message);
            }
        }
        public static void Log(string logString)
        {
            using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(@"Log.txt", true))
            {
                logFile.WriteLine(logString + " " + DateTime.Now.ToString("MM/dd/yyyy hh.mm.ss.ffffff tt"));
            }

        }

    }
}
